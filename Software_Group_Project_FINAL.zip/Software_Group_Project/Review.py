from db_connection import get_connection

def save_review(user_id, dealer_id, listing_id, rating, review):

    print (user_id,dealer_id,listing_id,rating,review)
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Reviews (user_id, dealer_id, listing_id, rating, description)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, dealer_id, listing_id, rating, review))
        conn.commit()
        return True
    except Exception as e:
        print(f"An error occurred: {e}")
        return False
    finally:
        cursor.close()



def get_reviews_for_user(user_id):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT rating, description, created_at , user_id 
            FROM Reviews 
            WHERE dealer_id = %s
            ORDER BY created_at DESC
        """, (user_id,))
        reviews = cursor.fetchall()
        return reviews if reviews else []
    except Exception as e:
        print(f"An error occurred while fetching reviews: {e}")
        return []
    finally:
        cursor.close()



def get_dealer_id(listing_id):
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM CarListings WHERE id = %s", (listing_id,))
        result = cursor.fetchone()
        return result[0] if result else None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None
    finally:
        cursor.close()