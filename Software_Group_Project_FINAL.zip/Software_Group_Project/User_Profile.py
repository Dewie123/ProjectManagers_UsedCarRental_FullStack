from db_connection import get_connection

def get_user_type_permissions():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM user_type_permissions
                       """)
    
    user_type_permissions = cursor.fetchall()

    return user_type_permissions

def update_user_type_permissions_in_db(id, user_type, create_listing, delete_listing, update_listing, view_listing, user_type_name):
    
    conn = get_connection()
    cursor = conn.cursor()

    query = """
        UPDATE user_type_permissions
        SET
            user_type = %s,
            create_listing = %s,
            delete_listing = %s,
            update_listing = %s,
            view_listing = %s,
            user_type_name = %s
        WHERE id = %s;
        """
    cursor.execute(query,(user_type,create_listing,delete_listing,update_listing,view_listing,user_type_name,id))

    conn.commit()
    cursor.close()
    return True

def add_user_type(user_type,user_type_name,create_listing,delete_listing,update_listing,view_listing):

    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO user_type_permissions (user_type, create_listing, delete_listing, update_listing, view_listing , user_type_name)
            VALUES (%s, %s, %s, %s, %s, %s)
                       """
    cursor.execute(query, (user_type, create_listing, delete_listing, update_listing, view_listing, user_type_name))
    conn.commit()
    cursor.close()
    return True

def deactivate_user_in_db(user_id):
    """Deactivate user by updating status in the database"""
    
    conn = get_connection()
    cursor = conn.cursor()

    # Update the status to 'inactive' in the users table
    update_status_query = """
    UPDATE users
    SET status = 'inactive'
    WHERE id = %s
    """
    cursor.execute(update_status_query, (user_id,))
    
    # Commit the changes and close the connection
    conn.commit()
    cursor.close()

    # Return True if the update was successful (at least one row updated)
    if cursor.rowcount > 0:
        return {"success": True, "message": "User deactivated successfully"}
    else:
        return {"success": False, "message": "Failed to deactivate user"}
    

def get_user_ids_by_type(user_type):
    conn = get_connection()
    query = "SELECT id FROM users WHERE user_type = %s"
    cursor = conn.cursor()
    cursor.execute(query, (user_type,))
    result = cursor.fetchall()
    cursor.close()
    return [row[0] for row in result]