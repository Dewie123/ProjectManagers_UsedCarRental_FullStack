from db_connection import get_connection

def insert_car_listing(listing_type,seller_name ,car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                       engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                       power, num_owners, images, user_id, dealer_name):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO CarListings (listing_type,carName, price, depreciation, mileage, roadTax, deregValue, coe, 
                                      engineCap, curbWeight, vehicleType, regDate, manufactured, transmission, omv, arf, 
                                      power, numOwners, user_id,sellerName,dealerName) 
            VALUES (%s,%s ,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (listing_type, car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                               engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                               power, num_owners, user_id,seller_name,dealer_name))
        listing_id = cursor.lastrowid

        if images:
            for img_path in images:
                cursor.execute("""
                INSERT INTO listing_images (listing_id, image_path)
                VALUES (%s, %s)""", (listing_id, img_path))
        
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cursor.close()

def get_listing_by_id(listing_id):
    
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM CarListings cl WHERE id = %s", (listing_id,))
    listing = cursor.fetchone()  
    cursor.execute("SELECT image_path FROM listing_images WHERE listing_id = %s", (listing_id,))
    images = cursor.fetchall()  
    cursor.execute("SELECT COUNT(listing_id) FROM SavedListings WHERE listing_id = %s",(listing_id,))
    shortlistCount = cursor.fetchone()
    image_paths = [img['image_path'].replace('static/', '').replace('\\', '/') for img in images]
    listing['image_paths'] = image_paths
    listing['shortlist_count'] = shortlistCount
    cursor.close()
    print("DEBUG: Retrieved listing:", listing)
    return listing

def get_filtered_listings(filters):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    print("Filter Values:")
    print(f"Car Model: {filters.car_model}")
    print(f"Min Price: {filters.min_price}")
    print(f"Max Price: {filters.max_price}")
    print(f"Depreciation: {filters.depreciation}")
    print(f"Registration Date: {filters.reg_date}")

    
    
    if filters.reg_date:
        reg_date_query = "regDate <= %s"
        reg_date_param = (filters.reg_date,)
    else:
        reg_date_query = "1=1"  
        reg_date_param = ()

   
    query = """
        SELECT cl.id, cl.carName, cl.price, MIN(li.image_path) as image_path
        FROM CarListings cl
        JOIN listing_images li ON li.listing_id = cl.id
        WHERE (carName LIKE %s OR %s = '')
          AND (price >= %s)
          AND (price <= %s OR %s = 0)
          AND (depreciation <= %s)
          AND {}
        GROUP BY cl.id, cl.carName, cl.price
    """.format(reg_date_query)

    
    params = (
        f"%{filters.car_model}%", filters.car_model,
        filters.min_price,
        filters.max_price, filters.max_price,
        filters.depreciation,
        *reg_date_param,  
    )
    
    cursor.execute(query, params)
    listings = cursor.fetchall()
    cursor.close()
    return listings

def get_profile(user_id):
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Retrieve account details for the user
        cursor.execute("""
            SELECT a.name, a.description, a.phone_number, a.email, ai.image_path
            FROM AccountDetails a
            LEFT JOIN AccountImages ai ON a.user_id = ai.user_id
            WHERE a.user_id = %s
        """, (user_id,))
        
        profile_data = cursor.fetchone()
        
        # Retrieve car listings for the user (either as dealer or seller)
        cursor.execute("""
            SELECT cl.id, cl.carName, cl.mileage, cl.price, MIN(li.image_path) AS image_path
            FROM CarListings cl
            LEFT JOIN listing_images li ON cl.id = li.listing_id
            WHERE cl.user_id = %s OR cl.sellerName = (SELECT name FROM AccountDetails WHERE user_id = %s)
            GROUP BY cl.id
        """, (user_id, user_id))
        
        listings = cursor.fetchall()

        cursor.execute("""
            SELECT user_type
            FROM users
            
            WHERE id = %s
        """, (user_id,))

        profile_data['user_type'] = cursor.fetchone()

        cursor.execute("""
            SELECT COUNT(sl.listing_id) AS saved_count
            FROM CarListings cl
            LEFT JOIN SavedListings sl ON cl.id = sl.listing_id
            WHERE cl.sellerName = (
                SELECT u.username FROM users u WHERE u.id = %s
            )
            GROUP BY cl.id
        """, (user_id,))

        
        shortlistCount = cursor.fetchone()
        profile_data['shortlist_count'] = shortlistCount
        
        
        # If listings exist, include them in the profile data
        if listings:
            profile_data['listings'] = listings
        else:
            profile_data['listings'] = None  # No listings for this user
        
        return profile_data
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None
    
    finally:
        cursor.close()


def update_car_listing(listing_id, listing_type, seller_name, car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                       engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                       power, num_owners, images, user_id, dealer_name):
    
    print("m.py",user_id)
    print("m.py",dealer_name)
    try:
        conn = get_connection()
        cursor = conn.cursor()
        # Update the CarListings table
        query = """
            UPDATE CarListings 
            SET listing_type = %s, carName = %s, price = %s, depreciation = %s, mileage = %s, roadTax = %s, deregValue = %s, coe = %s, 
                engineCap = %s, curbWeight = %s, vehicleType = %s, regDate = %s, manufactured = %s, transmission = %s, omv = %s, arf = %s, 
                power = %s, numOwners = %s, sellerName = %s, dealerName = %s, user_id = %s
            WHERE id = %s
        """
        cursor.execute(query, (listing_type, car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                               engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                               power, num_owners, seller_name, dealer_name, user_id, listing_id))
        
        # Delete existing images related to this listing
        cursor.execute("DELETE FROM listing_images WHERE listing_id = %s", (listing_id,))
        
        # Insert new images if any
        if images:
            for img_path in images:
                cursor.execute(""" 
                INSERT INTO listing_images (listing_id, image_path)
                VALUES (%s, %s)""", (listing_id, img_path))
        
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cursor.close()
        return True
    

def delete_listing(listing_id):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        # Delete the images associated with this listing
        cursor.execute("DELETE FROM listing_images WHERE listing_id = %s", (listing_id,))

        # Delete the listing from the CarListings table
        cursor.execute("DELETE FROM CarListings WHERE id = %s", (listing_id,))
            
        conn.commit()
        return True
        
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        return True
    

def get_filtered_listings(filters):

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    print("Filter Values:")
    print(f"Car Model: {filters.car_model}")
    print(f"Min Price: {filters.min_price}")
    print(f"Max Price: {filters.max_price}")
    print(f"Depreciation: {filters.depreciation}")
    print(f"Registration Date: {filters.reg_date}")

    
    
    if filters.reg_date:
        reg_date_query = "regDate <= %s"
        reg_date_param = (filters.reg_date,)
    else:
        reg_date_query = "1=1"  
        reg_date_param = ()

   
    query = """
        SELECT cl.id, cl.carName, cl.price, MIN(li.image_path) as image_path
        FROM CarListings cl
        JOIN listing_images li ON li.listing_id = cl.id
        WHERE (carName LIKE %s OR %s = '')
          AND (price >= %s)
          AND (price <= %s OR %s = 0)
          AND (depreciation <= %s)
          AND {}
        GROUP BY cl.id, cl.carName, cl.price
    """.format(reg_date_query)

    
    params = (
        f"%{filters.car_model}%", filters.car_model,
        filters.min_price,
        filters.max_price, filters.max_price,
        filters.depreciation,
        *reg_date_param,  
    )
    
    cursor.execute(query, params)
    listings = cursor.fetchall()
    cursor.close()
    return listings

def insert_seller_submission(listing_type,dealer_name ,car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                       engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                       power, num_owners, images, seller_name):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO SubmitDealership (listing_type,carName, price, depreciation, mileage, roadTax, deregValue, coe, 
                                      engineCap, curbWeight, vehicleType, regDate, manufactured, transmission, omv, arf, 
                                      power, numOwners,sellerName,dealerName) 
            VALUES (%s,%s ,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (listing_type, car_name, price, depreciation, mileage, road_tax, dereg_value, coe, 
                               engine_cap, curb_weight, vehicle_type, reg_date, manufactured, transmission, omv, arf, 
                               power, num_owners,seller_name,dealer_name))
        listing_id = cursor.lastrowid

        if images:
            for img_path in images:
                cursor.execute("""
                INSERT INTO seller_listing_images (listing_id, image_path)
                VALUES (%s, %s)""", (listing_id, img_path))
        
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cursor.close()

def get_normal_listings():
    query = """
    SELECT cl.id,cl.carName, cl.price, 
           (SELECT li.image_path 
            FROM listing_images li 
            WHERE li.listing_id = cl.id 
            LIMIT 1) as image_path
    FROM CarListings cl
    WHERE cl.listing_type = 'normal'
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query)
    listings = cursor.fetchall()
    for listing in listings:
        listing['image_path'] = listing['image_path'].replace('static/', '').replace('\\', '/')
        listing['image_path'] = listing['image_path'].split(',')[0]
    return listings

def get_premium_listings():
    query = """
    SELECT cl.id,cl.carName, cl.price, 
           (SELECT li.image_path 
            FROM listing_images li 
            WHERE li.listing_id = cl.id 
            LIMIT 1) as image_path
    FROM CarListings cl
    WHERE cl.listing_type = 'premium'
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query)
    listings = cursor.fetchall()
    for listing in listings:
        listing['image_path'] = listing['image_path'].replace('static/', '').replace('\\', '/')
        listing['image_path'] = listing['image_path'].split(',')[0]
    return listings

def get_all_submitted_dealership():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM SubmitDealership")
    listing = cursor.fetchall()  
    cursor.close()
    print("DEBUG: Retrieved listing:", listing)
    return listing

def get_all_listings():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
        SELECT cl.id AS listing_id, cl.carName, cl.price, cl.mileage, cl.depreciation,
        cl.roadTax, cl.deregValue, cl.coe, cl.engineCap, cl.curbWeight, cl.vehicleType,
        cl.regDate, cl.manufactured, cl.transmission, cl.omv, cl.arf, cl.power, cl.numOwners,
        cl.dealerName, cl.sellerName,
        GROUP_CONCAT(li.image_path ORDER BY li.id ASC) AS image_paths
        FROM CarListings cl
        LEFT JOIN listing_images li ON cl.id = li.listing_id
        GROUP BY cl.id;
                       """)
        listings = cursor.fetchall()
        return listings
    except Exception as e:
        print (f"An error occured: {e}")
        return []
    finally:
        cursor.close()