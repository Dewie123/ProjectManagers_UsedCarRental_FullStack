import mysql.connector

# Establish a connection to your database



def get_connection():

    return  mysql.connector.connect(
    host="localhost",
    user="root",
    password="1234",
    database="project_db",
    port=3305
)
