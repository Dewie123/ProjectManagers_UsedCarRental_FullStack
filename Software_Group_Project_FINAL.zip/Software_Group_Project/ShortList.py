from db_connection import get_connection


def save_listing_for_user(user_id, listing_id):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO SavedListings (user_id, listing_id)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE listing_id = listing_id
        """
        cursor.execute(query, (user_id, listing_id))
        conn.commit()
    except Exception as e:
        print(f"An error occurred while saving the listing: {e}")
        conn.rollback()
    finally:
        cursor.close()
        return True

def get_shortlisted_listings(user_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    query = """
        SELECT cl.id, cl.carName, cl.price, MIN(li.image_path) as image_path
        FROM CarListings cl
        JOIN SavedListings sl ON cl.id = sl.listing_id
        JOIN listing_images li ON li.listing_id = cl.id 
        WHERE sl.user_id = %s
        GROUP BY cl.id, cl.carName, cl.price
    """
    cursor.execute(query, (user_id,))
    listings = cursor.fetchall()
    cursor.close()
    return listings
