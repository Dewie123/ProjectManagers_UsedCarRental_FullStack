from db_connection import get_connection

def validate_user(username, password, user_type):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    query = "SELECT * FROM users WHERE username = %s AND password = %s AND user_type = %s"
    cursor.execute(query, (username, password, user_type))
    user = cursor.fetchone()
    cursor.close()
    return user


def admin_register_user(username, email, password, name, description, phone_number, user_type, image_paths):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Insert into the users table
        user_query = """
            INSERT INTO users (username, password, user_type)
            VALUES (%s, %s, %s)
        """
        cursor.execute(user_query, (username, password, user_type))
        
        # Get the generated user_id
        user_id = cursor.lastrowid
        
        # Insert into the AccountDetails table
        details_query = """
            INSERT INTO AccountDetails (name, description, phone_number, email, user_id)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(details_query, (name, description, phone_number, email,user_id))
        
        # Insert each image path into the AccountImages table
        if image_paths:
            for img_path in image_paths:
                image_query = """
                    INSERT INTO AccountImages (user_id, image_path)
                    VALUES (%s, %s)
                """
                cursor.execute(image_query, (user_id, img_path))
        
        # Commit the transaction
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cursor.close()
        return True
    
def get_all_users():
    try: 
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT u.id AS user_id, u.username,u.password ,u.user_type, 
            ad.name, ad.email, ad.phone_number, ad.description, 
            ai.image_path , u.status
            FROM users u
            JOIN AccountDetails ad ON u.id = ad.user_id
            LEFT JOIN AccountImages ai ON u.id = ai.user_id;   
                       """)
        user_profiles = cursor.fetchall()
        return user_profiles
    except Exception as e:
        print (f"An error occured: {e}")
        return []
    finally:
        cursor.close()  


def deactivate_user_in_db(user_id):
    """Deactivate user by updating status in the database"""
    conn = get_connection()
    cursor = conn.cursor()

    # Update the status to 'inactive' in the users table
    update_status_query = """
    UPDATE users
    SET status = 'inactive'
    WHERE id = %s
    """
    cursor.execute(update_status_query, (user_id,))
    
    # Commit the changes and close the connection
    conn.commit()
    cursor.close()

    # Return True if the update was successful (at least one row updated)
    if cursor.rowcount > 0:
        return {"success": True, "message": "User deactivated successfully"}
    else:
        return {"success": False, "message": "Failed to deactivate user"}
    


def update_user_in_db(user_id, username, password, email, name, description, phone_number, user_type):
    """Update user information in the database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    
    # Update users table (username, password, user_type)
    update_users_query = """
    UPDATE users
    SET username = %s, password = %s, user_type = %s
    WHERE id = %s
    """
    cursor.execute(update_users_query, (username, password, user_type, user_id))
    print("Executing query:", update_users_query)
    print("With parameters:", (username, password, user_type, user_id)) 
    
    # Update AccountDetails table (name, email, phone_number, description)
    update_account_details_query = """
    UPDATE AccountDetails
    SET name = %s, email = %s, phone_number = %s, description = %s
    WHERE user_id = %s
    """
    cursor.execute(update_account_details_query, (name, email, phone_number, description, user_id))
    print("Executing query:", update_account_details_query)
    print("With parameters:", (username, password, user_type, user_id))

    # Commit the changes and close the connection
    conn.commit()
    cursor.close()
    
    # Return True if the update was successful (at least one row updated in both tables)
    return cursor.rowcount > 0


def submit_registration(username, email, password, name, description, phone_number, user_type, image_paths):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Insert into the users table
        user_query = """
            INSERT INTO users (username, password, user_type)
            VALUES (%s, %s, %s)
        """
        cursor.execute(user_query, (username, password, user_type))
        
        # Get the generated user_id
        user_id = cursor.lastrowid
        
        # Insert into the AccountDetails table
        details_query = """
            INSERT INTO AccountDetails (name, description, phone_number, email, user_id)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(details_query, (name, description, phone_number, email,user_id))
        
        # Insert each image path into the AccountImages table
        if image_paths:
            for img_path in image_paths:
                image_query = """
                    INSERT INTO AccountImages (user_id, image_path)
                    VALUES (%s, %s)
                """
                cursor.execute(image_query, (user_id, img_path))
        
        # Commit the transaction
        conn.commit()
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        cursor.close()

def get_dealerships():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.name, a.description, a.phone_number, a.email, ai.image_path , a.user_id
            FROM AccountDetails a
            LEFT JOIN AccountImages ai ON a.user_id = ai.user_id
            LEFT JOIN users u ON a.user_id = u.id
            WHERE u.user_type = 3
        """)
        dealerships = cursor.fetchall()  # This will return a list of tuples
        return dealerships
    except Exception as e:
        print(f"An error occurred: {e}")
        return []
    finally:
        cursor.close()